import java.util.EventObject;

/**
 * Created by inosphe on 15. 5. 17..
 */
public class ProtocolEvent extends EventObject {
    public ProtocolEvent(Object source){
        super(source);
    }
}
